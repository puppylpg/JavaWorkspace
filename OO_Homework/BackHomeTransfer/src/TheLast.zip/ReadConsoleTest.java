import static org.junit.Assert.*;

import org.junit.Test;


public class ReadConsoleTest {

	ReadConsole readCon = new ReadConsole();
	
	@Test
	public void testGetPoster() {
		int poster = 3;
		this.readCon.setPoster(poster);
		int Poster = this.readCon.getPoster();
		assertSame(poster, Poster);
	}

	@Test
	public void testGetMessage() {
		String message = "message";
		this.readCon.setMessage(message);
		String Message = this.readCon.getMessage();
		assertTrue("false in testGetMessage", message == Message);
	}
	
	@Test
	public void testPostInit() {
		this.readCon.postInit();
		int G[][] = this.readCon.getG();
		boolean flag = false;
		if(G == null){
			flag = true;
		}
		assertTrue("false in testPostInit", flag);
	}

	@Test
	public void testGetMailbox() {
		int mailBox = 4;
		this.readCon.setMailbox(mailBox);
		int MailBox = this.readCon.getMailbox();
		assertSame(mailBox, MailBox);
	}

	@Test
	public void testGetTime() {
		int time = 7;
		this.readCon.setTime(time);
		int Time = this.readCon.getTime();
		assertTrue("false in thesGetTime", time == Time);
	}

	@Test
	public void testSetPoster() {
		int poster = 3;
		this.readCon.setPoster(poster);
		int Poster = this.readCon.getPoster();
		assertSame(poster, Poster);
	}
	
	@Test
	public void testSetMessage() {
		String message = "message";
		this.readCon.setMessage(message);
		String Message = this.readCon.getMessage();
		assertTrue("false in testSetMessage", message == Message);
	}
	
	@Test
	public void testSetTime() {
		int time = 7;
		this.readCon.setTime(time);
		int Time = this.readCon.getTime();
		assertTrue("false in thesSetTime", time == Time);
	}

	@Test
	public void testInit() {
		this.readCon.init();
		int[][] T = this.readCon.getG();
		assertNotSame(T, null);
	}

	@Test
	public void testGetG() {
		int[][] G = {{1,2},{3,4}};
		this.readCon.setG(G);
		int [][] T = this.readCon.getG();
		assertSame(G, T);
	}
	
	@Test
	public void testSetMailbox() {
		int mailBox = 4;
		this.readCon.setMailbox(mailBox);
		int MailBox = this.readCon.getMailbox();
		assertSame(mailBox, MailBox);
	}

	@Test
	public void testSetG() {
		int[][] G = {{1,2},{3,4}};
		this.readCon.setG(G);
		int [][] T = this.readCon.getG();
		assertSame(G, T);
	}

	@Test
	public void testJudgeInput() {
		String s = "S";
		int t = 1;
		boolean flag = this.readCon.judgeInput(s, t);
		assertFalse("true in testJudgeInput0", flag);
	}
	
	@Test
	public void testJudgeInput_vice() {
		String s = "S";
		int t = 100;
		boolean flag = this.readCon.judgeInput(s, t);
		assertFalse("true in testJudgeInput0", flag);
	}

	@Test
	public void testStructure() {
		this.readCon.init();
		int[][] T = this.readCon.getG();
		boolean flag = (T == null) ? true : false;
		assertTrue("false in testStructure", !flag);
	}

}
