import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;


public class FindPathTest {

	FindPath findp = new FindPath();
	
	@Test
	public void testInit0() {
		int G[][] = {{1,2},{3,4}};
		int totalMachine = 2;
		ArrayList< ArrayList <Integer> > path = new ArrayList< ArrayList <Integer>>();

		findp.init(G, totalMachine, path);
		
		boolean result = (2 == totalMachine);
		assertTrue("fail testInit0", result);
	}
	
	@Test
	public void testInit1() {
		int G[][] = {{1,2},{3,4}};
		int totalMachine = 2;
		ArrayList< ArrayList <Integer> > path = new ArrayList< ArrayList <Integer>>();

		findp.init(G, totalMachine, path);

		int he[][] = {{1,2},{3,4}};
		boolean result = (G.equals(he));
		assertFalse("true testInit1", result);
	}
	
	@Test
	public void testInit2() {
		int G[][] = {{1,2},{3,4}};
		int totalMachine = 2;
		ArrayList< ArrayList <Integer> > path = new ArrayList< ArrayList <Integer>>();

		findp.init(G, totalMachine, path);
		
		path.get(0);
		
		ArrayList<Integer> p = new ArrayList<Integer>();
		
		boolean result = ( p.equals(path.get(0)) );
		assertTrue("fail testInit2", result);
	}
	
	
	@Test
	public void testInit3() {
		
		int G[][] = {{1,2},{3,4}};
		int totalMachine = 2;
		ArrayList< ArrayList <Integer> > path = new ArrayList< ArrayList <Integer>>();

		findp.init(G, totalMachine, path);
		
		path.get(0).add(7);
		
		boolean result = (7 == path.get(0).get(0));
		assertTrue("fail testInit3", result);
	}

	@Test
	public void testGetG0() {
		int T[][] = null;
		boolean flag = false;
		findp.run();
		T = findp.getG();
		if(T != null)
			flag = true;
		
		assertFalse("true testGetG", flag);
	}

	@Test
	public void testGetG1() {
		int O[][] = null;
		int G[][] = null;
		O = findp.getG();
		assertSame(O, G);
	}

}
