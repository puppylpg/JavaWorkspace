import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import Utility.Receiver;
import Utility.Sender;
import Utility.Transfer;


public class ReadConfigurationTest {

	ReadConfiguration readConfig = new ReadConfiguration();
	
	@Test
	public void testInit() {
		ArrayList<Sender> send = new ArrayList<Sender>();
		send.add(new Sender());
		boolean flag = true;
		ArrayList<Receiver> receive = new ArrayList<Receiver>();
		ArrayList<Transfer> trans = new ArrayList<Transfer>();
		this.readConfig.init(send, receive, trans);
		
		if(this.readConfig.getSend() == null)
			flag = false;
		
		assertTrue("false in testInit", flag);
	}

	@Test
	public void testGetTotalMachine() {
		int num = 5;
		ReadConfiguration.setTotalMachine(num);
		int t = ReadConfiguration.getTotalMachine();
		assertSame(t, num);
		if(t == 0)
			fail("wrong in testGetTotalMachine occurs");
	}

	@Test
	public void testSetTotalMachine() {
		int num = 5;
		ReadConfiguration.setTotalMachine(num);
		int t = ReadConfiguration.getTotalMachine();
		assertSame(t, num);
	}

	@Test
	public void testSetSender() {
		int num = 4;
		ReadConfiguration.setSender(num);
		int t = ReadConfiguration.getSender();
		assertSame(t, num);
		if(t == 0)
			fail("wrong in testSetSender occurs");
	}

	@Test
	public void testSetReceiver() {
		int num = 6;
		ReadConfiguration.setReceiver(num);
		int t = ReadConfiguration.getReceiver();
		assertSame(t, num);
	}

	@Test
	public void testSetTransfer() {
		int num = 3;
		ReadConfiguration.setTransfer(num);
		int t = ReadConfiguration.getTransfer();
		assertSame(t, num);
	}

	@Test
	public void testGetTransfer() {
		int num = 3;
		ReadConfiguration.setTransfer(num);
		int t = ReadConfiguration.getTransfer();
		assertSame(t, num);
	}

	@Test
	public void testGetSender() {
		int num = 4;
		ReadConfiguration.setSender(num);
		int t = ReadConfiguration.getSender();
		assertSame(t, num);
	}

	@Test
	public void testGetReceiver() {
		int num = 6;
		ReadConfiguration.setReceiver(num);
		int t = ReadConfiguration.getReceiver();
		assertSame(t, num);
	}

	@Test
	public void testFind() {
		ArrayList<Sender> send = new ArrayList<Sender>();
		send.add(new Sender());
		boolean flag = true;
		ArrayList<Receiver> receive = new ArrayList<Receiver>();
		ArrayList<Transfer> trans = new ArrayList<Transfer>();
		this.readConfig.find();
		
		if(this.readConfig.getSend() == null)
			flag = false;
		
		assertFalse("true in tesFind", flag);
	}
	
	@Test
	public void testGetSend(){
		ArrayList<Sender> send = new ArrayList<Sender>();
		send.add(new Sender());
		boolean flag = true;
		ArrayList<Receiver> receive = new ArrayList<Receiver>();
		ArrayList<Transfer> trans = new ArrayList<Transfer>();
		this.readConfig.init(send, receive, trans);
		if(this.readConfig.getSend() == null)
			flag = false;
		assertTrue("false in testGetSend", flag);
	}

}
