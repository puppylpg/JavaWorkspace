import static org.junit.Assert.*;

import org.junit.Test;


public class MainClassTest {

	MainClass mainClass = new MainClass();
	
	@Test
	public void testDecode() {
		String s = "hello";
		String t = this.mainClass.decode(s);
		assertSame(s, t);
	}

}
