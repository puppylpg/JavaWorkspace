package Utility;

//Overview: the transfer machine extends from machine
public class Transfer extends Machine{
	public Transfer(){
		super.setFunction("Transfer");
	}
	
	// repOK: same as its parent class.
}
