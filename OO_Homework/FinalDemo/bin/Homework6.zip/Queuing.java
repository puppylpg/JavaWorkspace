
public class Queuing {
	Queue queuing = new Queue();

	public Queue getQueuing() {		//TODO: new a queuing in class Test()
		return queuing;
	}
	
}
